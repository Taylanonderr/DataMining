
import sqlite3
from TurkishNLP.helpers import to_lower


def replace_cap_letter(word):
    # degistir listesindeki ilk öğeyi ikincisi ile değiştiriyoruz. Yani şapkalı harfleri normale çeviriyoruz.
    replace_letter = [('â', 'a'), ('ê', 'e'), ('î', 'i'), ('ô', 'o'), ('û', 'u')]
    for tpl in replace_letter:
        word = word.replace(tpl[0], tpl[1])
    return word


# sozluk_tekli.txt içindeki veriler veritabanına işlenir

with open('sozluk_tekli.txt', 'r', encoding='utf-8') as fl:
    may_sozluk = [line.strip().split('\t') for line in fl]
del fl

with sqlite3.connect('tr_NLP.sqlite') as vt:
    im = vt.cursor()
    im.execute("DROP TABLE IF EXISTS tr_sozluk")
    im.execute("CREATE TABLE IF NOT EXISTS tr_sozluk (sozcuk, sozcuk_turu, ses_olayi, sozcuk_konusu, sozcuk_kokeni)")
    for veri in may_sozluk:
        veri[0] = replace_cap_letter(to_lower(veri[0]))
        im.execute("INSERT INTO tr_sozluk VALUES (?, ?, ?, ?, ?)", veri)
    vt.commit()
