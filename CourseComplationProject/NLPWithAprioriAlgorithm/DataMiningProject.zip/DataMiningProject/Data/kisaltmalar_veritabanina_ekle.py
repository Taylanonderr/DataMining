
import sqlite3

# ../TxtDatabase/ShortList.txt içindeki veriler veritabanına işlenir

with open('ShortList.txt', 'r', encoding='utf-8') as fl:
    kisaltmalar = [line.strip().split(',') for line in fl]
del fl

with sqlite3.connect('tr_NLP.sqlite') as vt:
    im = vt.cursor()
    im.execute("DROP TABLE IF EXISTS tr_kisaltmalar")
    im.execute("CREATE TABLE IF NOT EXISTS tr_kisaltmalar (kisaltma, acilimi)")
    for veri in kisaltmalar:
        if len(veri) > 2:
            veri = [veri[0], ';'.join(veri[1:])]
        im.execute("INSERT INTO tr_kisaltmalar VALUES (?, ?)", veri)
    vt.commit()
