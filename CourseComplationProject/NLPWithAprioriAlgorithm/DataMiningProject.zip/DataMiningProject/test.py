
from optparse import OptionParser  # parse command-line parameters
from apriori import *
from init import *

if __name__ == '__main__':

    # Run and print
    objApriori = Apriori(0.12, 0.5)
    itemCountDict, freqSet = objApriori.fit("transaction.csv")


    for key, value in freqSet.items():
        print('frequent {}-term set:'.format(key))
        print('-' * 20)
        for itemset in value:
            print(deascii(str(list((itemset)))))
        print()

    # Return rules with regard of `rhs`
    rhs=frozenset(['EKMEK'])
    rules = objApriori.getSpecRules(rhs)
    print('-' * 20)
    print('rules refer to {}'.format(list(rhs)))
    for key, value in rules.items():
        print('{} -> {}: {}'.format(list(key), list(rhs), value))
