from word_processing import *
from helpers import *
from word_processing import *
from Morphological.MorphologicalLR import ClsEkBul as Ceb
from Statistic.TextStatistic import Statistic as Stat
from Tokenization.SentenceTokenization import token, word_tokenize, sentence_token_wsign, \
    sentence_token
from file_processing import *


def deascii(str_grp: str):      #Kelimede Türkçe olması gereken karakterleri dönüştürür.
    """

    :type str_grp: object
    """
    from Asciidecoder.Asciidecoder import Deasciifier
    return Deasciifier(str_grp).convert_to_turkish()


def find_suffix(word: str):     #Kelime köklerinin Eklere ayrılmış hali
    return Ceb(word).result


def find_stems(word: str):      #Kelime köklerini bulduğüm method
    return Ceb(word).stems


def view_statistic(str_grp: str):
    return Stat(str_grp).text_statistic()


def ntow(number: str):      #sayıdan yazıya çevirme
    from helpers import number_to_word
    return number_to_word(number)


def wton(word: str):
    from helpers import word_to_number
    return word_to_number(word)
