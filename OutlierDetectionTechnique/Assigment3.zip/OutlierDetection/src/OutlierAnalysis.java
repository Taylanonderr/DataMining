import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;

public class OutlierAnalysis {

    public static void main(String[] args) {
        // upload list of files/directory to blob storage
        File read_file = new File("Notlar.xlsx");

        if (read_file.isFile()) {
            Workbook workbook;
            try {
                workbook = WorkbookFactory.create(new FileInputStream(read_file.getName()));
                // Get the first sheet.
                Sheet sheet = workbook.getSheetAt(0);

                //we will search for column index containing string "Your Column Name" in the row 0 (which is first row of a worksheet

                Integer columnNo = null;
                DataFormatter fmt = new DataFormatter();
                //output all not null values to the list
                List<String>[] cells = new ArrayList[5];
                List<String>[] Point_Anomalies = new ArrayList[4];
                List<String>[] Collective_Anomalies = new ArrayList[8];
                List<Integer>[] Point_AnomaliesIndexes= new ArrayList[4];
                List<List>[] Group_Anomalies= new ArrayList[4];
                for (int i = 0; i < 5; i++) {
                    cells[i] = new ArrayList<String>();
                    if(i<4) {
                        Point_Anomalies[i] = new ArrayList<String>();
                        Point_AnomaliesIndexes[i] = new ArrayList<Integer>();
                        Group_Anomalies[i]= new ArrayList<>();
                    }
                }
                for (int i = 0; i < 8; i++)
                {
                    Collective_Anomalies[i] = new ArrayList<String>();
                }
                // Get the first cell.
                Row row = sheet.getRow(0);
                //Cell cell = row.getCell(0);
                int t=0;
                for (Cell cell : row) {
                    String columnWanted = cell.getStringCellValue();
                    // Column header names.
                    if (cell.getStringCellValue().equals(columnWanted)) {
                        columnNo = cell.getColumnIndex();
                    }

                    if (columnNo != null) {
                        for (Row row1 : sheet) {
                            Cell c = row1.getCell(columnNo);
                            if (c == null || c.getCellType() == Cell.CELL_TYPE_BLANK) {
                                // Nothing in the cell in this row, skip it
                            } else {
                                String value=fmt.formatCellValue(c);
                                cells[t].add(value);
                            }
                        }
                        System.out.println(cells[t]);
                        t++;

                    } else {
                        System.out.println("could not find column " + columnWanted + " in first row of " + read_file.getName());
                    }
                }
                System.out.println("\n\n ---- Point_Anomalies ----");
                Z_score(cells,2.3,Point_Anomalies,Point_AnomaliesIndexes);
                for(int j=0;j<Point_Anomalies.length;j++){
                    System.out.println(Point_Anomalies[j]);
                }
                System.out.println("\n\n ---- Collective_Anomalies ----");
                collective_anomalies(cells,Collective_Anomalies);
                for(int j=0;j<Collective_Anomalies.length;j++){
                    if(j%2==0)
                        System.out.println("Score is bigger than 100 for "+cells[(j/2)+1].get(0)+"lesson.");
                    else if(j%2==1)
                        System.out.println("Score is smaller than 20 for "+cells[(j/2)+1].get(0)+"lesson.");
                    System.out.println(Collective_Anomalies[j]);
                }
                System.out.println("\n\n ---- Group_Anomalies ----");
                group_anomalies(Group_Anomalies,Point_Anomalies,Point_AnomaliesIndexes);
                for(int j=0;j<Group_Anomalies.length;j++){
                    System.out.println(cells[j+1].get(0));
                    System.out.println(Group_Anomalies[j]);
                }
            } catch (InvalidFormatException | IOException e) {
                e.printStackTrace();
            }
        }
    }

    /*according to z_score fill in the point anomalies list*/
    public static void Z_score(List<String> data[],double threshold,List<String> Outliear_anomalies[],List<Integer> Outliear_anomaliesIndexes[]) {
        double z_score=0;
        double check_anomaly_score=0;
        for(int i=1; i<data.length;i++){
            double sum_students=sum_scores(data[i]);
            double mean=sum_students/(data[i].size()-1);
            System.out.println("Mean of lesson "+ data[i].get(0)+" is "+mean);
            double derivation=standard_deviation(data[i],mean);
            for(int t=1;t<data[i].size();t++){
                double score =  Double.parseDouble(String.valueOf(data[i].get(t)));
                check_anomaly_score=(score-mean)/derivation;
                if(check_anomaly_score<=(threshold*-1)){
                    Outliear_anomalies[i-1].add(data[0].get(t));
                    Outliear_anomaliesIndexes[i-1].add(t);
                }
            }

        }
    }

    /*sum all scores in dataset*/
    public static double sum_scores(List<String> data){
        double sum=0;
        for(int t=1;t<data.size();t++){
            double score =  Double.parseDouble(String.valueOf(data.get(t)));
            sum+=score;
        }
        return sum;
    }

    /*standart sapma for dataset each lesson*/
    public static double standard_deviation(List<String> data, double mean){
        double derivation=0;
        for(int t=1;t<data.size();t++){
            double score =  Double.parseDouble(String.valueOf(data.get(t)));
            double r = (double) Math.pow((score - mean), 2);
            derivation+=r;
        }
        derivation = (derivation / (data.size()));
        return Math.sqrt(derivation);
    }

    /*check anomalies according to some conditions*/
    public static void collective_anomalies(List<String> data[],List<String> Outliear_anomalies[]){
        for(int i=1; i<data.length;i++){
            for(int t=1;t<data[i].size();t++){
                double score =  Double.parseDouble(String.valueOf(data[i].get(t)));
                if(score>100){ /*first error condition*/
                    Outliear_anomalies[2*(i-1)].add(data[0].get(t));
                }
                else if(score<20){  /*Second unexpected anomalie condition*/
                    Outliear_anomalies[(2*i)-1].add(data[0].get(t));
                }
            }

        }
    }

    /*Grouped point anomalies according to continuous*/
    public static void group_anomalies(List<List> Outliear_anomalies[],List<String> PointOutliear_anomalies[],List<Integer> Outliear_anomaliesIndexes[]) {
        int current_index=0,before_index=0,flag=1;
        List temp_data=new ArrayList();
        for(int i=0; i<Outliear_anomaliesIndexes.length;i++){
            before_index=Outliear_anomaliesIndexes[i].get(0);
            for(int t=1;t<Outliear_anomaliesIndexes[i].size();t++){
                current_index=Outliear_anomaliesIndexes[i].get(t);
                if(before_index+1==current_index){
                    if(!temp_data.contains(PointOutliear_anomalies[i].get(t-1))) {
                        if(flag==1)
                            temp_data=new ArrayList();
                        flag=0;
                        temp_data.add(PointOutliear_anomalies[i].get(t - 1));
                        temp_data.add(PointOutliear_anomalies[i].get(t));
                    }
                    else{
                        flag=0;
                        temp_data.add(PointOutliear_anomalies[i].get(t));
                    }
                }
                else{
                    if(flag==0) {
                        Outliear_anomalies[i].add(temp_data);
                        temp_data=new ArrayList();
                    }
                    flag=1;
                }
                before_index=current_index;
            }
            if(flag==0) {
                Outliear_anomalies[i].add(temp_data);
                temp_data=new ArrayList();
            }
            flag=1;
        }
    }
}